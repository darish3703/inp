import React from 'react'

export default function Home() {
  return (
    <div>
        <h1>this is home</h1>
    </div>
  )
}
