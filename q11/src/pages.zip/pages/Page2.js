import React from 'react'

export default function Page2() {
  return (
    <div>
        <h1>this is page 2</h1>
    </div>
  )
}
